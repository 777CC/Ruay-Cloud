'use strict';

console.log('Loading function');
const doc = require('dynamodb-doc');
const dynamo = new doc.DynamoDB();
const async = require('async');


const userDataKeys = ["email","tel","gender","firstName", "lastName", "interest","birthday"];

function setValue(dataset,valueName,newValue){
    if (valueName in dataset) {
            dataset[valueName].newValue = newValue;
            dataset[valueName].op = 'replace';
        }
}

exports.handler = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    const modifiedEvent = event;

    // Check for the event type
    if (event.eventType === 'SyncTrigger') {
        // Modify value for a key
        //setValue(modifiedEvent.datasetRecords,'firstName','wellcome from cognito sync trigger.' );
        
        //if ('firstName' in event.datasetRecords) {
        //    modifiedEvent.datasetRecords.playerName.newValue = 'wellcome from cognito sync trigger.';
        //    modifiedEvent.datasetRecords.playerName.op = 'replace';
        //}

        // Remove a key
        //if ('testremove' in event.datasetRecords) {
            //console.log(JSON.stringify(modifiedEvent.datasetRecords.testremove));
            //modifiedEvent.datasetRecords.testremove.op = 'remove';
        //}
        
        // Add a key
        //if (!('SampleKey3' in event.datasetRecords)) {
        //    modifiedEvent.datasetRecords.SampleKey3 = {
        //        newValue: 'ModifyValue3',
        //        op: 'replace',
       //     };
       // }
        
        //Check deleted key
        //if ('SampleKey3' in event.datasetRecords) {
        //    if (event.datasetRecords.SampleKey3 === null){
        //        console.log('Error : SampleKey3 is null');
        //    }
        //}
        
        if('updateTime' in event.datasetRecords){
            if(event.datasetRecords.updateTime.newValue !== event.datasetRecords.updateTime.oldValue){
                async.series([
                    getUserItem(callback,modifiedEvent),
                    function(callback) {
                        console.log('get reward');
                }
                ], function(err) { //This function gets called after the two tasks have called their "task callbacks"
                    if (err) return console.log(err);
                    context.done(null, modifiedEvent);
                });
            }
        }
       
    }
};

function getUserItem(callback,modifiedEvent){
    var itemParams = {
                        TableName : process.env.TicketTableName,
                        ProjectionExpression:"createdOn, roundId, reserveNumber, announced",
                        KeyConditionExpression: "ownerId = :ownerId ",
                        ExpressionAttributeValues: {
                            ":owerId": modifiedEvent.identityId
                            //":ownerId": '777'
                        }
                    };
                    dynamo.query(itemParams, function(err, data) {
                        if (err) {
                            console.log("Unable to query. Error:", JSON.stringify(err, null, 2));
                        } else {
                            console.log("Query succeeded.");
                            //data.Items.forEach(function(item) {
                            //});
                                console.log(JSON.stringify(data.Items));
                                if ('ticket' in event.datasetRecords) {
                                    modifiedEvent.datasetRecords.ticket.newValue = JSON.stringify(data.Items);
                                    modifiedEvent.datasetRecords.ticket.op = 'replace';
                                    }
                                else {
                                    modifiedEvent.datasetRecords.ticket = {
                                        newValue: JSON.stringify(data.Items),
                                        op: 'replace',
                                    };
                                }
                                callback();
                                //context.done(null, modifiedEvent);
                        }
                    });
}

function getUserData(context,modifiedEvent){
    var id =  modifiedEvent.identityId;
        //var id =  "test";
        dynamo.getItem(
                    {
                        "TableName": process.env.UserTableName,
                        "Key": { "id" :id}
                    }
                    ,function(err, data) {
                        if(err){
                            console.log("Error : " +  JSON.stringify(err));
                        }
                        else if(Object.keys(data).length === 0){
                            console.log("addUser");
                            addUser(id,context,modifiedEvent);
                        }
                        else{
                        console.log("data : " +  JSON.stringify(data));
                         //callback(null,"Erorr : " + JSON.stringify(data));
                         context.done(null, modifiedEvent);
                        }
                    });
}

function nextDailyRewardTime(){
    var today = new Date();
 
    //if(20 < 21)
    var tomorrow;
    if(today.getUTCHours() > 21){
    //if(20 < 21){
    	tomorrow = Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate(),21);
    }
    else{
    	tomorrow = Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate(),21) + 86400000;
    }
    return tomorrow;
}

function addDataset(userData,datasetRecords){
    userDataKeys.forEach( (item, index) => {
        if (item in datasetRecords) {
            if(item === "interest")
            {
                var interests = datasetRecords[item].newValue.split('#').filter(function(el) {return el.length !== 0});
                userData[item] = dynamo.Set(interests, "S");
            }
            else{
                userData[item] = datasetRecords[item].newValue;
            }
        }
    });
}



function addUser(id,context,modifiedEvent)
{
    //"ticket": dynamo.Set(["fdsafdsafdsa","fdsafdasfdasf"], "S")
    //error!! stringset cannot be empty "ticket": dynamo.Set([], "S")
    //date use in UTC standard
    //"interest":dynamo.Set(["game","dev"], "S"),
    
    var user = {
        "id": id,
        "updateTime":Date.now(),
        "satang": 0
    };
    
    addDataset(user,modifiedEvent.datasetRecords);
    console.log( JSON.stringify(user));
    dynamo.putItem({
                        TableName: process.env.UserTableName,
                        Item: user
                        }
                        ,function(err, data) {
                             console.log("data : " +  JSON.stringify(data));
                            context.done(null, modifiedEvent);
                    });
                    
                    

}
