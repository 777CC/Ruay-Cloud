var async = require("async");
var AWS = require("aws-sdk");

var im = require("gm").subClass({ imageMagick: true });
var s3 = new AWS.S3();
let doc = require('dynamodb-doc');
let dynamo = new doc.DynamoDB();

var CONFIG = require("./config.json");
var imageSizes;
function getImageType(objectContentType) {
    if (objectContentType === "image/jpeg") {
        return "jpeg";
    } else if (objectContentType === "image/png") {
        return "png";
    } else {
        throw new Error("unsupported objectContentType " + objectContentType);
    }
}

function cross(left, right) {
    var res = [];
    left.forEach(function (l) {
        right.forEach(function (r) {
            res.push([l, r]);
        });
    });
    return res;
}

function getImagefromS3(originalKey, width, height, context, callback) {
	s3.getObject({
		"Bucket": CONFIG.bucketOriginalName,
		"Key": originalKey
	}, function (err, data) {
		if (err) {
			cb(err);
		} else {
			resizeImage(context, callback, {
				"originalKey": originalKey,
				"contentType": data.ContentType,
				"imageType": getImageType(data.ContentType),
				"buffer": data.Body,
				"requestWidth": width,
				"requestHeight": height,
			});
		}
	});
}

function toResizedImageName(name,w,h) {
	return name + "/" + w + "x" + h + "_" + name;
}

function resizeImage(context, callback, image) {
	im(image.buffer).resize(image.requestWidth, image.requestHeight).toBuffer(image.imageType, function (err, buffer) {
		if (err) {
			cb(err);
		} else {
			s3.putObject({
				"Bucket": CONFIG.bucketResizedName,
				"Key": toResizedImageName(image.originalKey, image.requestWidth, image.requestWidth),
				"Body": buffer,
				"ContentType": image.contentType
			}, function (err, data) {
				if (err) {
					console.log(err.code);
					//context.fail(err);
				} else {
					//context.succeed();
				    callback(null, JSON.stringify(data));
				    
				}
			});
		}
	});
}

function addSizeToDynamoDB()
{
    if (imageSizes === undefined) {
        var params = {
            TableName: "Config",
            Key: {
                "Name": ImageSizes
            }
        };
        dynamo.getItem(params, function (err, data) {
            if (err) {

            } else {
                //console.log(JSON.stringify(data));
                imageSizes = data;
                console.log(JSON.stringify(imageSizes));
            }
        });
    }
    else
    {
        console.log(JSON.stringify(imageSizes));
    }
    
    //dynamo.updateItem({

    //}
    //    , callback);
}

//Test event
//{
//	"imageName": "image.png",
//  "w": "50",
//  "h": "50"
//}
//Test example
//{
//	"bucketName" : 
//	"imagename": "14292376_1247537558631713_6046755132720745485_n.jpg",
//    "w": "50",
//    "h": "50"
//}
exports.handler = function (event, context, callback) {
	//Check image resolution.
	if (event.w > 8 && event.h > 8) {
		originalKey = decodeURIComponent(event.imageName.replace(/\+/g, " "));
		console.log(toResizedImageName(originalKey, event.w , event.h));
			
		s3.headObject({
			"Bucket": CONFIG.bucketResizedName,
			"Key": toResizedImageName(originalKey, event.w ,event.h) ,
		}, function (err, url) {
			if (err) {
				console.log(JSON.stringify(err));
				getImagefromS3(originalKey, event.w, event.h, context, callback);
			}
			else {
				callback(null,"url" + JSON.stringify(url));
			}
		});
    }
    else {
        callback("Image not exist", event.imageName);
    }
};

